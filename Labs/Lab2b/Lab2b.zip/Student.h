#ifndef Student_H
#define Student_H

#include <iostream>
#include <string>
using namespace std;


class Student{
    private:
        string name;
        int score;
        char grade;
    
    public:
        Student();
        Student(string, int);
        ~Student();
        void print();
};

#endif