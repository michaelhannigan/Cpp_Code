#include "Student.h"
#include <string>
using namespace std;


Student::Student(){
    
}

Student::Student(string nm, int sc)
{
    name = nm;
    score = sc;
    char temp [ ] = {'F', 'F', 'F', 'F', 'F', 'F', 'D', 'C', 'B', 'A', 'A'}; 
    grade = temp[sc/10];
}

Student::~Student(){
    
}

void Student::print(){
    cout<<"Name:" <<name<<" "<<"Score:"<<score<<" "<<"Grade:"<<grade<<endl;
}