/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include "Student.h"
#include <string>
using namespace std;


int main()
{
    Student tom = Student("Tom", 85);
    Student alice = Student("Alice", 71);
    Student jack = Student("Jack", 93);
    Student janet = Student("Janet", 76);
    Student john = Student("John", 66);
    tom.print();
    alice.print();
    jack.print();
    janet.print();
    john.print();
}

