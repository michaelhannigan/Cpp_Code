#include <string>
#include "Rectangle.h"
using namespace std;


Rectangle::Rectangle(){
    height = 1;
    width = 1;
}

Rectangle::Rectangle(double w, double h){
    width = w;    
    height = h;

}

double Rectangle::getWidth(){
    return width;
}

double Rectangle::getHeight(){
    return height;
}

void Rectangle::setWidth(double w){
    width = w;
}

void Rectangle::setHeight(double h){
    height = h;
}

double Rectangle::getArea(){
    return height*width;
}

double Rectangle::getPerimeter(){
    return height*2+width*2;
}