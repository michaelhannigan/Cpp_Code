#ifndef REC_H
#define REC_H

#include <string>

using namespace std;


class Rectangle{
    private:
        double width;
        double height;
    
    public:
        Rectangle();
        Rectangle(double, double);
        double getWidth();
        double getHeight();
        void setWidth(double);
        void setHeight(double);
        double getArea();
        double getPerimeter();
};


#endif