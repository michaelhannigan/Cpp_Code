#include <iostream>
#include "Rectangle.h"
using namespace std;

int main()
{
    Rectangle r1(4,40);
    Rectangle r2(3.5,35.9);
    
    cout <<"First Rectangle--->"<<" Width:" << r1.getWidth() <<" Height:"<<r1.getHeight()
    << " Area:"<<r1.getArea()<< " Perimeter:" <<r1.getPerimeter()<< endl;
    
    cout <<"First Rectangle--->"<<" Width:" << r2.getWidth() <<" Height:"<<r2.getHeight()
    << " Area:"<<r2.getArea()<< " Perimeter:" <<r2.getPerimeter()<< endl;
}
